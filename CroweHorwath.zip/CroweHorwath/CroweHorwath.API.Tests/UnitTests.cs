﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using CroweHorwath.API;
using CroweHorwath.API.Implementations;
using System.Collections.Generic;
using CroweHorwath.API.Interfaces;

namespace CroweHorwath.API.Tests
{
    [TestClass]
    public class UnitTests
    {
        const string c_testString1 = "teststring1";
        const string c_repoKey1 = "atest1";
        const string c_testString2 = "teststring2";
        const string c_repoKey2 = "atest2";
        const string c_testString3 = "teststring3";
        const string c_repoKey3 = "atest3";
        readonly Dictionary<string, string> c_repoData = new Dictionary<string, string>() { { c_repoKey1, c_testString1 }, { c_repoKey2, c_testString2 }, { c_repoKey3, c_testString3 } };
        readonly IFormatter c_formatter = new PlainTextFormatter();

        [TestMethod]
        public void APIOutputsToConsoleCorrectly()
        {
            // Arrange
            TextWriter oldOut = Console.Out;
            var filename = Path.GetTempFileName();
            try
            {
                using (var outputStream = new FileStream(filename, FileMode.OpenOrCreate, FileAccess.ReadWrite))
                {
                    using (StreamWriter writer = new StreamWriter(outputStream))
                    {
                        // switch console
                        Console.SetOut(writer);

                        // Act
                        var api = new MessageWriter(new ConsoleWriter(c_formatter), new InMemoryRepository(c_repoData));
                        api.DisplayMessage(c_repoKey2);

                        // restore console output
                        Console.SetOut(oldOut);

                    }
                }
                // Assert
                using (var textReader = File.OpenText(filename))
                {
                    string line = textReader.ReadLine();
                    Assert.IsTrue(line == c_testString2);
                }
            }
            finally
            {
                // ensur we clean up after the test
                if (File.Exists(filename))
                {
                    File.Delete(filename); 
                }
            }
        }

        [TestMethod]
        public void APIDisplayMessageValidatesParameters()
        {
            try
            {
                var api = new MessageWriter(new ConsoleWriter(new PlainTextFormatter()), new InMemoryRepository(c_repoData));
                api.DisplayMessage(null);
                Assert.Fail("DisplayMessage should throw an exception when message name is null");
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex is ArgumentNullException);
            }

            try
            {
                var api = new MessageWriter(new ConsoleWriter(new PlainTextFormatter()), new InMemoryRepository(c_repoData));
                api.DisplayMessage(string.Empty);
                Assert.Fail("DisplayMessage should throw an exception when message name is an empty string");
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex is ArgumentNullException);
            }
        }

        [TestMethod]
        public void APIConstructorValidatesParameters()
        {
            try
            {
                var api = new MessageWriter(null, new InMemoryRepository(c_repoData));
                Assert.Fail("Null writer should throw an exception");
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex is ArgumentNullException);
            }

            try
            {
                var api = new MessageWriter(new ConsoleWriter(c_formatter), null);
                Assert.Fail("No repository writer should throw an exception");
            }
            catch (Exception ex)
            {
                Assert.IsTrue(ex is ArgumentNullException);
            }
        }
    }
}
