﻿using CroweHorwath.API.Interfaces;
using CroweHorwath.API.Implementations;
using System;

namespace CroweHorwath.API
{
    public class MessageWriter
    {
        private readonly IWriter m_writer;
        private readonly IRepository m_repository;

        public MessageWriter(IWriter writer, IRepository repository)
        {
            if (repository == null)
            {
                throw new ArgumentNullException("Repository must be configured");
            }

            if (writer == null)
            {
                throw new ArgumentNullException("Writer must be configured");
            }

            m_writer = writer;
            m_repository = repository;
        }

        public void DisplayMessage(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException("Message name must be specified.");
            }
            m_writer.WriteLine(m_repository.GetMessageByName(name));
        }
    }
}
