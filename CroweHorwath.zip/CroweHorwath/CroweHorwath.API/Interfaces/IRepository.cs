﻿namespace CroweHorwath.API.Interfaces
{
    public interface IRepository
    {
        string GetMessageByName(string message);
    }
}
