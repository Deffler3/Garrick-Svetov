﻿namespace CroweHorwath.API.Interfaces
{
    public interface IFormatter
    {
        string Format(string text);
    }
}
