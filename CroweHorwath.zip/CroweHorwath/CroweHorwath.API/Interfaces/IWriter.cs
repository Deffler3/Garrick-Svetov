﻿namespace CroweHorwath.API.Interfaces
{
    public interface IWriter
    {
        void WriteLine(string text);
    }
}
