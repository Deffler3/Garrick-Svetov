﻿using System;
using System.Collections.Generic;
using CroweHorwath.API.Interfaces;

namespace CroweHorwath.API.Implementations
{
    public class InMemoryRepository : IRepository
    {
        public readonly Dictionary<string, string> c_defaultMessages = new Dictionary<string, string> { { "hello", "Hello World" } };
        public readonly Dictionary<string, string> m_messages;

        public InMemoryRepository()
        {
            m_messages = c_defaultMessages; 
        }
        public InMemoryRepository(Dictionary<string, string> messages)
        {
            m_messages = messages;
        }

        public string GetMessageByName(string name)
        {
            if (string.IsNullOrEmpty(name))
            {
                throw new ArgumentNullException("Message name must be specified");
            }

            if (!m_messages.ContainsKey(name.ToLower()))
            {
                throw new ArgumentException("Message name is invalid");
            }

            return m_messages[name.ToLower()];
        }
    }
}
