﻿using CroweHorwath.API.Interfaces;

namespace CroweHorwath.API.Implementations
{
    // This formatter implements plain text formatter (i.e no formatting at all)
    public class PlainTextFormatter : IFormatter
    {
        public string Format(string text)
        {
            return text;
        }
    }
}
