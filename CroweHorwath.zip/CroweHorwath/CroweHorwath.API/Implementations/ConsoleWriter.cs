﻿using System;
using CroweHorwath.API.Interfaces;

namespace CroweHorwath.API.Implementations
{
    public class ConsoleWriter : IWriter
    {
        private IFormatter m_formatter;

        public ConsoleWriter(IFormatter formatter)
        {
            if (formatter == null)
            {
                throw new ArgumentNullException("Formatter must be specified");
            }
            m_formatter = formatter;
        }

        public void WriteLine(string text)
        {
            if (text == null)
            {
                throw new ArgumentNullException("Text cannot be null");
            }
            Console.WriteLine(m_formatter.Format(text));
        }

    }
}
