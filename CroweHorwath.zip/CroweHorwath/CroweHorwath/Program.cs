﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CroweHorwath.API;
using CroweHorwath.API.Implementations;

namespace CroweHorwath
{
    class Program
    {
        static void Main(string[] args)
        {
            var api = new MessageWriter(new ConsoleWriter(new PlainTextFormatter()), new API.Implementations.InMemoryRepository());
            api.DisplayMessage("Hello");
        }
    }
}
